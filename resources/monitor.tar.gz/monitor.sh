#!/bin/sh
java -Djava.library.path=./lib -cp monitor-1.0-SNAPSHOT-jar-with-dependencies.jar uk.ac.manchester.rtccfd.monitor.SystemResourcesUsage /home/hadoop/log/
